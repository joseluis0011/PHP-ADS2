-- Dump de la Base de Datos
-- Fecha: domingo 26 noviembre 2017 - 00:44:14
--
-- Version: 1.1.1, del 26-11-2017 , insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `basecelulares`
-- ------------------------------------------------------
-- Server version	10.1.13-MariaDB

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS administrador;
CREATE TABLE `administrador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) DEFAULT NULL,
  `correo` varchar(50) NOT NULL,
  `nive_usua` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrador`
--

LOCK TABLES administrador WRITE;
INSERT INTO administrador VALUES(, , , , , , );
INSERT INTO administrador VALUES(, , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `movimientos`
--

DROP TABLE IF EXISTS movimientos;
CREATE TABLE `movimientos` (
  `id_movimientos` int(11) NOT NULL AUTO_INCREMENT,
  `cantidadm` int(30) NOT NULL,
  `fecha_movimiento` datetime NOT NULL,
  `tipo_movimiento` varchar(50) NOT NULL,
  `admin` varchar(30) NOT NULL,
  `id_producto_m` int(50) NOT NULL,
  `motivo` varchar(30) DEFAULT NULL,
  UNIQUE KEY `id_movimientos` (`id_movimientos`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movimientos`
--

LOCK TABLES movimientos WRITE;
INSERT INTO movimientos VALUES(, , , , , , );
INSERT INTO movimientos VALUES(, , , , , , );
INSERT INTO movimientos VALUES(, , , , , , );
INSERT INTO movimientos VALUES(, , , , , , );
INSERT INTO movimientos VALUES(, , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS productos;
CREATE TABLE `productos` (
  `id_productos` int(11) NOT NULL AUTO_INCREMENT,
  `modelo` varchar(50) NOT NULL,
  `descripcion` varchar(400) NOT NULL,
  `marca` varchar(40) NOT NULL,
  `cantidad` int(20) DEFAULT NULL,
  `costo` bigint(30) NOT NULL,
  `p_publico` int(30) NOT NULL,
  `provedor` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL,
  PRIMARY KEY (`id_productos`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productos`
--

LOCK TABLES productos WRITE;
INSERT INTO productos VALUES(, , , , , , , , );
INSERT INTO productos VALUES(, , , , , , , , );
INSERT INTO productos VALUES(, , , , , , , , );
INSERT INTO productos VALUES(, , , , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `taller`
--

DROP TABLE IF EXISTS taller;
CREATE TABLE `taller` (
  `modelo` varchar(50) NOT NULL,
  `descripcion_p` varchar(300) NOT NULL,
  `fecha_entrada` datetime NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `marca` varchar(50) NOT NULL,
  `n_serie` varchar(50) NOT NULL,
  `falla` varchar(300) NOT NULL,
  `cantidad` int(5) NOT NULL,
  `id_taller` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_taller`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taller`
--

LOCK TABLES taller WRITE;
INSERT INTO taller VALUES(, , , , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS usuarios;
CREATE TABLE `usuarios` (
  `id_usuarios` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `fechai` varchar(40) NOT NULL,
  `direccion` varchar(300) NOT NULL,
  `telefono` int(20) NOT NULL,
  PRIMARY KEY (`id_usuarios`),
  UNIQUE KEY `cedula` (`cedula`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES usuarios WRITE;
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.